// CONFIGURACIÓN: reemplaza estos dos valores con los de tu NUEVO proyecto Supabase.
// La clave publishable/anon es pública. NUNCA uses service_role ni secret keys aquí.
window.BARBER_CONFIG = {
  supabaseUrl: 'https://TU-PROYECTO.supabase.co',
  supabaseAnonKey: 'TU_CLAVE_PUBLICABLE'
};
